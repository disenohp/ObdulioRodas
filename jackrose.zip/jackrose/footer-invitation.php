<?php
/**
 * The template for displaying the footer on invitaion page template.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Jack_&_Rose
 */

?>
		
				</div><!-- .wrapper -->
			</div><!-- #content -->

			<?php jackrose_background_music(); ?>

		</div><!-- #page -->

		<?php wp_footer(); ?>

	</body>
</html>
