<div class="jackrose-sow-rsvp-form">
	<?php echo do_shortcode( '[contact-form-7 id="' . $instance['form'] . '"]' ); ?>
</div>