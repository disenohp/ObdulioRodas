<?php header( 'Content-type: text/css; charset: UTF-8' ); ?>

html {
	box-sizing: border-box;
	height: 100% !important;
}
*,
*:before,
*:after {
	box-sizing: inherit;
}
*:focus {
	outline: 0;
}

body {
	height: 100%;
	background: #fff;
	color: #888;
	font-family: serif;
	font-size: 14px;
	line-height: 1.85;
}
h1, h2, h3, h4, h5, h6 {
	margin: 2rem 0 1rem;
	color: #444;
	font-style: italic;
}
h1:first-child, h2:first-child, h3:first-child, h4:first-child, h5:first-child, h6:first-child {
	margin-top: 0 !important;
}
h1 a, h2 a, h3 a, h4 a, h5 a, h6 a {
	color: inherit;
}
h1 {
	font-size: 200%;
	line-height: 1.3;
}
h2 {
	font-size: 175%;
	line-height: 1.4;
}
h3 {
	font-size: 150%;
	line-height: 1.5;
}
h4 {
	font-size: 130%;
	line-height: 1.6;
}
h5 {
	font-size: 110%;
	line-height: 1.7;
}
h6 {
	font-size: 100%;
}
p {
	margin: 0 0 1.5em;
}
a {
	text-decoration: none;
	-webkit-transition: all 0.25s ease-in-out;
	transition: all 0.25s ease-in-out;
}
a:hover,
a:focus,
a:active {
	color: #444;
	outline: 0;
}
dfn,
cite,
em,
i {
	font-style: italic;
}
blockquote {
	margin: 0 0 1.5em;
	background-color: #f3f3f3;
	padding: 1.5em 2em;
	font-size: 120%;
	font-style: italic;
}
blockquote p:last-child {
	margin-bottom: 0;
}
blockquote cite {
	display: block;
	opacity: 0.6;
}
address {
	margin: 0 0 1.5em;
}
pre {
	background: #eee;
	font-family: "Courier 10 Pitch", Courier, monospace;
	font-size: 15px;
	font-size: 0.9375rem;
	line-height: 1.6;
	margin: 0 0 1.5em;
	max-width: 100%;
	overflow: auto;
	padding: 1.2em;
}
code,
kbd,
tt,
var {
	font-family: Monaco, Consolas, "Andale Mono", "DejaVu Sans Mono", monospace;
	font-size: 15px;
	font-size: 0.9375rem;
}
code {
	background-color: rgba(0, 0, 0, 0.05);
}
abbr,
acronym {
	border-bottom: 1px dotted #666;
	cursor: help;
}
mark,
ins {
	background: #fff9c0;
	text-decoration: none;
}
big {
	font-size: 125%;
}
hr {
	background-color: #e5e5e5;
	border: 0;
	height: 1px;
	margin: 1.5em 0;
}
ul,
ol {
	margin: 0 0 1.5em 3em;
	padding: 0;
}
ul {
	list-style: disc;
}
ol {
	list-style: decimal;
}
li > ul,
li > ol {
	margin-bottom: 0;
	margin-left: 1.5em;
}
dt {
	font-weight: bold;
}
dd {
	margin: 0 0 1.5em 1.5em;
}
img {
	max-width: 100%;
	height: auto;
}
table {
	margin: 0 0 1.5em;
	width: 100%;
}
embed,
iframe,
object {
	max-width: 100%;
}

::-webkit-input-placeholder{
	color: #ccc;
}
:-moz-placeholder{
	color: #ccc;
}
::-moz-placeholder{
	color: #ccc;
}
:-ms-input-placeholder {
	color: #ccc;
}

body#tinymce {
	max-width: 1080px;
	margin: 1em;	
}
body {
	font-family: <?php echo urldecode( $_REQUEST[ 'typography_body_font_family' ] ); ?>;
}
h1, h2, h3, h4, h5, h6 {
	font-family: "<?php echo urldecode( $_REQUEST[ 'typography_headings_font_family' ] ); ?>";
}
a {
	color: <?php echo urldecode( $_REQUEST[ 'color_accent' ] ); ?>;
}

/* Alignment */
.alignleft {
	display: inline;
	float: left;
	margin-right: 1.5em;
}
.alignright {
	display: inline;
	float: right;
	margin-left: 1.5em;
}
.aligncenter {
	clear: both;
	display: block;
	margin-left: auto;
	margin-right: auto;
}

/* Caption */
.wp-caption {
	margin-bottom: 1.5em;
	max-width: 100%;
}
.wp-caption img[class*="wp-image-"] {
	display: block;
	margin-left: auto;
	margin-right: auto;
}
.wp-caption .wp-caption-text {
	margin: 0.8075em 0;
	font-size: 0.85em;
	font-style: italic;
	text-align: center;
}

/* Gallery */
.gallery {
	margin-bottom: 1.5em;
}
.gallery-item {
	display: inline-block;
	text-align: center;
	vertical-align: top;
	width: 100%;
}
.gallery-columns-2 .gallery-item {
	max-width: 50%;
}
.gallery-columns-3 .gallery-item {
	max-width: 33.33%;
}
.gallery-columns-4 .gallery-item {
	max-width: 25%;
}
.gallery-columns-5 .gallery-item {
	max-width: 20%;
}
.gallery-columns-6 .gallery-item {
	max-width: 16.66%;
}
.gallery-columns-7 .gallery-item {
	max-width: 14.28%;
}
.gallery-columns-8 .gallery-item {
	max-width: 12.5%;
}
.gallery-columns-9 .gallery-item {
	max-width: 11.11%;
}
.gallery-caption {
	display: block;
	color: inherit;
	font-size: 0.85em; 
	font-style: italic;
	text-align: center;
	word-break: break-all;
}

.entry-content > * {
  margin-bottom: 20px;
}

.entry-content > *:last-child {
	margin-bottom: 0;
}

p.has-background {
	padding: 1.5em 2em;
}

.editor-post-title__block {
	font-size: inherit;
}
.editor-post-title__block .editor-post-title__input {
	font-size: 150%;
	line-height: 1.4;
	font-family: inherit;
	font-style: italic;
	font-weight: normal;
	line-height: 1.5;
	letter-spacing: 0.1em;
	text-transform: uppercase;
	text-align: center;
}

.has-small-font-size {
	font-size: 0.85em !important;
}

.has-regular-font-size,
.has-normal-font-size {
	font-size: 1em !important;
}

.has-medium-font-size {
	font-size: 1.1em !important;
	line-height: calc( 0.95 * 1.7);
}

.has-large-font-size {
	font-size: 1.25em !important;
	line-height: calc( 0.875 * 1.7);
}

.has-larger-font-size,
.has-huge-font-size {
	font-size: 1.5em !important;
	line-height: calc( 0.8 * 1.7);
}

.wp-block {
	max-width: 760px;
}
.wp-block[data-align="wide"] {
	max-width: 1080px;
}
.wp-block[data-align="full"] {
	max-width: none;
}

.wp-block-file a.wp-block-file__button:active, 
.wp-block-file a.wp-block-file__button:focus, 
.wp-block-file a.wp-block-file__button:hover, 
.wp-block-file a.wp-block-file__button:visited {
	opacity: 1;
}
.wp-block-image figcaption,
.wp-block-embed figcaption,
.wp-block-video figcaption {
	color: inherit;
	font-size: 0.85em;
	font-style: italic;
	text-align: center;
	word-break: break-all;
}
.wp-block-columns:first-child {
	margin-top: 0;
}

.wp-block-columns:last-child {
	margin-bottom: 0;
}

.wp-block-columns > .wp-block-column {
	margin-top: 20px;
}

.wp-block-columns > .wp-block-column > *:first-child {
	margin-top: 0;
}

.wp-block-columns > .wp-block-column > *:last-child {
	margin-bottom: 0;
}

@media screen and (max-width: 767px) {
	.wp-block-columns > .wp-block-column {
		-ms-flex-preferred-size: 100% !important;
		flex-basis: 100% !important;
		margin-left: 0;
		margin-right: 0;
	}
}

@media screen and (min-width: 768px) {
	.wp-block-columns {
		-ms-flex-wrap: nowrap;
		flex-wrap: nowrap;
	}
	.wp-block-columns > .wp-block-column {
		margin-left: 1rem;
		margin-right: 1rem;
	}
}

.wp-block-quote {
	padding: 0.5em 2em;
	border-left-width: 0.25rem;
	border-left-style: solid;
	border-color: inherit;
}

.wp-block-quote[style*="center"] {
	padding-left: 0;
	padding-right: 0;
	border-left: none;
}

.wp-block-quote[style*="right"] {
	padding-left: 0;
	border-left: none;
	border-right-width: 0.25rem;
	border-right-style: solid;
}

.wp-block-quote cite {
	font-size: 1rem;
	font-style: normal;
}

.wp-block-quote.is-style-large {
	margin: 1.5rem 0;
	padding: 0.5em 2em;
}

.wp-block-quote.is-style-large p {
	font: unset;
	font-size: 1.2em;
}

.wp-block-quote.is-style-large cite {
	font-size: 1rem;
	text-align: unset;
}

.wp-block-pullquote {
	border-left: none !important;
	padding: 1.2em 0 !important;
	margin-top: 2rem !important;
	margin-bottom: 2rem !important;
	border-top: 2px solid;
	border-top-color: inherit;
	border-bottom: 2px solid;
	border-bottom-color: inherit;
	color: inherit;
}

.wp-block-pullquote p {
	font: inherit;
	font-size: 1.2em;
	color: inherit;
}

.wp-block-pullquote cite {
	font-size: 1rem;
	color: inherit;
	text-transform: none;
	font-style: normal;
}

.wp-block-group.has-background {
	padding: 1.5em 2em;
}

.wp-block-group__inner-container {
	margin: 0 auto;
}

.wp-block-group__inner-container > * {
	margin: 0 0 20px;
}

.wp-block-group__inner-container > *:first-child {
	margin-top: 0;
}

.wp-block-group__inner-container > *:last-child {
	margin-bottom: 0;
}

.wp-block-embed__wrapper {
	display: flex;
	justify-content: center;
}

.wp-block-button__link, 
.wp-block-file .wp-block-file__button {
	display: inline-block;
	padding: 0.7em 1.5em;
	border: 1px solid;
	border-radius: 0;
	transition: all 0.25s ease-in-out;

	font-size: 12px;
	font-style: italic;
	line-height: inherit;
	letter-spacing: 0.1em;
	text-transform: uppercase;
}

.wp-block-button__link:hover, 
.wp-block-file .wp-block-file__button:hover,
.wp-block-button__link:focus, 
.wp-block-file .wp-block-file__button:focus,
.wp-block-button__link:active, 
.wp-block-file .wp-block-file__button:active {
	outline: 0;
	text-decoration: none;
}

.wp-block-button.is-style-outline a.wp-block-button__link {
	background-color: transparent;
	border-color: currentColor;
	color: inherit;
}

.wp-block-button__link, .wp-block-file .wp-block-file__button {
	background-color: <?php echo urldecode( $_REQUEST[ 'color_button_bg' ] ); ?>;
	border-color: <?php echo urldecode( $_REQUEST[ 'color_button_bg' ] ); ?>;
	color: <?php echo urldecode( $_REQUEST[ 'color_button_text' ] ); ?>;
}

.wp-block-button__link:hover, .wp-block-file .wp-block-file__button:hover, 
.wp-block-button__link:focus, .wp-block-file .wp-block-file__button:focus {
	background-color: <?php echo urldecode( $_REQUEST[ 'color_button_bg_hover' ] ); ?>;
	border-color: <?php echo urldecode( $_REQUEST[ 'color_button_bg_hover' ] ); ?>;
	color: <?php echo urldecode( $_REQUEST[ 'color_button_text_hover' ] ); ?>;
}